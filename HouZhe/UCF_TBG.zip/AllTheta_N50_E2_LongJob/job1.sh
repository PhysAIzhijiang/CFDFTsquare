#!/bin/bash -l
#SBATCH -q normal
#SBATCH --job-name=test-job
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --cpus-per-task=16
#SBATCH --time=7-00:00:00
#SBATCH -p mini

module load conda
conda activate /sharedata01/zhehou/packages

echo Job Start
python -u run1.py
echo Job Done
 



