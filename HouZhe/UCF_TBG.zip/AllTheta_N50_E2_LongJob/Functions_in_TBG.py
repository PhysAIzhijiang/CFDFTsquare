import time
import numpy as np
from scipy.sparse import csr_matrix

'''%This function is written to calculate the hopping matrix 
t_ij of the twisted bilayer graphene;'''


def t_ij(x, y, z):
    a = 1.418
    a_I = 3.349  # all in units of Angstrom(A)
    gamma0 = 2.7
    gamma1 = 0.48  # all in units of eV
    chi = 2.218  # 1 / A
    Boundary = 2 * np.sqrt(3) * a  # a boundary away which the hopping is zero
    r = np.sqrt(x * x + y * y + z * z)  # all in units of Angstrom(A)
    n = z / r
    Vsigma = gamma1 * np.exp(chi * (a_I - r))
    Vpi = - gamma0 * np.exp(chi * (a - r))
    f = np.heaviside(Boundary + 1e-4 - np.sqrt(x * x + y * y), 0.5) \
        * (n * n * Vsigma + (1 - n * n) * Vpi)
    return f


'''Y coordinate generator'''


def Y_coordinate_generator(x):
    Y = np.array([0] * x)
    S = -1
    for ii in range(0, x, 1):
        S = S + 1 + np.remainder(ii + 1, 2)
        Y[ii] = S
    return Y


'''This program is written for calculating the coordinates
of all carbon atoms inside the central region. All media-suffixed
variables are temporal parameters;'''


def Twisted_Coordinates(N, theta, d):
    if N % 2 == 1:
        print('Wrong input!')
    # Basic parameters
    a = 1.418
    a_I = 3.349  # all in units of Angstrom (A)
    epsilon_bottom = 0
    epsilon_top = 0  # on-site energy, will both be fixed in the present project
    W = (3 * N / 2 - 1) * a  # width of the nanoribbon
    R = W / 2  # radius of the disc
    Lc_L = round(R / (2 * np.sqrt(3) * a)) + 1
    Lc_R = Lc_L  # the number of supercells of the left side in the
    # central region
    Lc = Lc_L + 1 + Lc_R

    ## 1. Coordinates for each site in the middle bottom supercell
    Xcoordinate_MiddleBottomCell = np.kron(a * np.array([-np.sqrt(3) / 2, 0, np.sqrt(3) / 2, np.sqrt(3)]),
                                           np.array([1] * N))
    Y_media1 = a * (Y_coordinate_generator(int(N / 2) + 1) - 3 / 2)
    Y_media1 = Y_media1[1::]
    Y_media1 = np.hstack((-Y_media1[::-1], Y_media1))
    Y_media2 = a * (Y_coordinate_generator(int(N / 2)))
    Y_media2 = np.hstack((-Y_media2[::-1], Y_media2))
    Ycoordinate_MiddleBottomCell = np.hstack((Y_media1, Y_media2, Y_media1, Y_media2))
    Y_media1 = 0 * Y_media1
    Y_media2 = 0 * Y_media2

    # Hamiltonian of the supercell (intra)
    H00 = np.zeros([4 * N, 4 * N])
    for ii in range(0, 4 * N - 1, 1):
        for jj in range(ii + 1, 4 * N, 1):
            r_ij_x = Xcoordinate_MiddleBottomCell[jj] - Xcoordinate_MiddleBottomCell[ii]
            r_ij_y = Ycoordinate_MiddleBottomCell[jj] - Ycoordinate_MiddleBottomCell[ii]
            H00[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)
    H00 = epsilon_bottom * np.eye(4 * N) + H00 + np.matrix.getH(H00)

    # Hamiltonian of the supercell (inter)
    H01 = np.zeros([4 * N, 4 * N])
    for ii in range(0, 4 * N, 1):
        for jj in range(0, 4 * N, 1):
            r_ij_x = 2 * np.sqrt(3) * a + Xcoordinate_MiddleBottomCell[jj] - Xcoordinate_MiddleBottomCell[ii]
            r_ij_y = Ycoordinate_MiddleBottomCell[jj] - Ycoordinate_MiddleBottomCell[ii]
            H01[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)

    ## 2. Search for all bottom sites within the disc
    Xcoordinate_bottomDisc = []
    Ycoordinate_bottomDisc = []
    for cc in range(-Lc_L, Lc_R + 1, 1):
        for jj in range(0, 4 * N, 1):
            X_media = Xcoordinate_MiddleBottomCell[jj] + cc * 2 * np.sqrt(3) * a
            Y_media = Ycoordinate_MiddleBottomCell[jj]
            if np.sqrt(X_media * X_media + Y_media * Y_media) < (R + 1e-4):
                Xcoordinate_bottomDisc.append(X_media)
                Ycoordinate_bottomDisc.append(Y_media)
        X_media = 0
        Y_media = 0
    length_Disc = len(Xcoordinate_bottomDisc)

    ## 3. Get the coordinates of all top sites
    Xcoordinate_topDisc = [0 * c for c in Xcoordinate_bottomDisc]
    Ycoordinate_topDisc = [0 * c for c in Ycoordinate_bottomDisc]
    for ii in range(0, length_Disc, 1):
        X_media = Xcoordinate_bottomDisc[ii]
        Y_media = Ycoordinate_bottomDisc[ii]
        Xcoordinate_topDisc[ii] = X_media * np.cos(theta) - Y_media * np.sin(theta)
        Ycoordinate_topDisc[ii] = X_media * np.sin(theta) + Y_media * np.cos(theta)

    ## 4. Sort x-coordinate to get asending sequence
    Xcoordinate_sort_topDisc = np.sort(Xcoordinate_topDisc)
    index_media = sorted(range(len(Xcoordinate_topDisc)), key=lambda k: Xcoordinate_topDisc[k])
    Ycoordinate_sort_topDisc = np.array([Ycoordinate_topDisc[ii] for ii in index_media])

    ## 5. Define a cell-list to save coordinates of top sites by regions
    Cell_topXCoordinate = [None] * Lc
    Cell_topYCoordinate = [None] * Lc
    S_media = 0
    for cc in range(-Lc_L, Lc_R + 1, 1):
        L_media = np.sum(np.dot(np.heaviside(Xcoordinate_sort_topDisc - (-a * 3 * np.sqrt(3) / 4 + cc * 2 * np.sqrt(3) \
                                                                         * a - np.exp(-10)), 0), \
                                np.heaviside((a * 5 * np.sqrt(3) / 4 + cc * 2 * np.sqrt(3) * a) - np.exp(-10) \
                                             - Xcoordinate_sort_topDisc, 0)))
        L_media = int(L_media)
        S_media = S_media + L_media
        if L_media == 0:
            Cell_topXCoordinate[cc + Lc_L] = []
            Cell_topYCoordinate[cc + Lc_L] = []
        else:
            Cell_topXCoordinate[cc + Lc_L] = Xcoordinate_sort_topDisc[S_media - L_media: S_media]
            Cell_topYCoordinate[cc + Lc_L] = Ycoordinate_sort_topDisc[S_media - L_media: S_media]

    ## 6. Get on-site Hamiltonian of the central region
    Cell_Hc00 = [None] * Lc
    for cc in range(-Lc_L, Lc_R + 1, 1):
        topXCoordinate_media = Cell_topXCoordinate[cc + Lc_L]
        topYCoordinate_media = Cell_topYCoordinate[cc + Lc_L]
        bottomXCoordinate_media = Xcoordinate_MiddleBottomCell + cc * 2 * np.sqrt(3) * a
        bottomYCoordinate_media = Ycoordinate_MiddleBottomCell
        length_top_media = len(topXCoordinate_media)
        if length_top_media == 0:
            H00_media = H00
        else:
            H00_media_bottom = H00
            H00_media_top = np.zeros([length_top_media, length_top_media])
            H00_media_bt = np.zeros([4 * N, length_top_media])
            # Get H00_media_top
            for ii in range(0, length_top_media - 1, 1):
                for jj in range(ii + 1, length_top_media, 1):
                    r_ij_x = topXCoordinate_media[jj] - topXCoordinate_media[ii]
                    r_ij_y = topYCoordinate_media[jj] - topYCoordinate_media[ii]
                    H00_media_top[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)
            H00_media_top = epsilon_top * np.eye(length_top_media) + H00_media_top + np.matrix.getH(H00_media_top)
            # Get H00_media_bt
            for ii in range(0, 4 * N, 1):
                for jj in range(0, length_top_media, 1):
                    r_ij_x = topXCoordinate_media[jj] - bottomXCoordinate_media[ii]
                    r_ij_y = topYCoordinate_media[jj] - bottomYCoordinate_media[ii]
                    H00_media_bt[ii, jj] = t_ij(r_ij_x, r_ij_y, d)
            # Get H00_media
            H00_media = np.vstack([np.hstack([H00_media_bottom, H00_media_bt]), \
                                   np.hstack([np.matrix.getH(H00_media_bt), H00_media_top])])
        Cell_Hc00[cc + Lc_L] = csr_matrix(H00_media)

    ## 7. Get Hopping Hamiltonian of the central region
    Cell_Hc01 = [None] * (Lc - 1)
    for cc in range(-Lc_L, Lc_R, 1):
        topXCoordinate_media0 = Cell_topXCoordinate[cc + Lc_L]
        topYCoordinate_media0 = Cell_topYCoordinate[cc + Lc_L]
        topXCoordinate_media1 = Cell_topXCoordinate[cc + Lc_L + 1]
        topYCoordinate_media1 = Cell_topYCoordinate[cc + Lc_L + 1]
        bottomXCoordinate_media0 = Xcoordinate_MiddleBottomCell + cc * 2 * np.sqrt(3) * a
        bottomXCoordinate_media1 = Xcoordinate_MiddleBottomCell + (cc + 1) * 2 * np.sqrt(3) * a
        length_top_media0 = len(topXCoordinate_media0)
        length_top_media1 = len(topXCoordinate_media1)

        # Classifying into four cases:
        if length_top_media0 == 0 and length_top_media1 == 0:
            H01_media = H01

        if length_top_media0 == 0 and length_top_media1 > 0:
            H01_media = np.zeros([4 * N, 4 * N + length_top_media1])
            H01_media_bottom = H01
            H01_media_bt = np.zeros([4 * N, length_top_media1])
            for ii in range(0, 4 * N, 1):
                for jj in range(0, length_top_media1, 1):
                    r_ij_x = topXCoordinate_media1[jj] - bottomXCoordinate_media0[ii]
                    r_ij_y = topYCoordinate_media1[jj] - Ycoordinate_MiddleBottomCell[ii]
                    H01_media_bt[ii, jj] = t_ij(r_ij_x, r_ij_y, d)
            H01_media = np.hstack([H01_media_bottom, H01_media_bt])

        if length_top_media0 > 0 and length_top_media1 == 0:
            H01_media = np.zeros([4 * N + length_top_media0, 4 * N])
            H01_media_bottom = H01
            H01_media_tb = np.zeros([length_top_media0, 4 * N])
            for ii in range(0, length_top_media0, 1):
                for jj in range(0, 4 * N):
                    r_ij_x = bottomXCoordinate_media1[jj] - topXCoordinate_media0[ii]
                    r_ij_y = Ycoordinate_MiddleBottomCell[jj] - topYCoordinate_media0[ii]
                    H01_media_tb[ii, jj] = t_ij(r_ij_x, r_ij_y, -d)
            H01_media = np.vstack([H01_media_bottom, H01_media_tb])

        if length_top_media0 > 0 and length_top_media1 > 0:
            H01_media = np.zeros([4 * N + length_top_media0, 4 * N + length_top_media1])
            H01_media_bottom = H01
            H01_media_bt = np.zeros([4 * N, length_top_media1])
            H01_media_tb = np.zeros([length_top_media0, 4 * N])
            H01_media_top = np.zeros([length_top_media0, length_top_media1])
            for ii in range(0, 4 * N, 1):
                for jj in range(0, length_top_media1, 1):
                    r_ij_x = topXCoordinate_media1[jj] - bottomXCoordinate_media0[ii]
                    r_ij_y = topYCoordinate_media1[jj] - Ycoordinate_MiddleBottomCell[ii]
                    H01_media_bt[ii, jj] = t_ij(r_ij_x, r_ij_y, d)
            for ii in range(0, length_top_media0, 1):
                for jj in range(0, 4 * N):
                    r_ij_x = bottomXCoordinate_media1[jj] - topXCoordinate_media0[ii]
                    r_ij_y = Ycoordinate_MiddleBottomCell[jj] - topYCoordinate_media0[ii]
                    H01_media_tb[ii, jj] = t_ij(r_ij_x, r_ij_y, -d)
            for ii in range(0, length_top_media0, 1):
                for jj in range(0, length_top_media1, 1):
                    r_ij_x = topXCoordinate_media1[jj] - topXCoordinate_media0[ii]
                    r_ij_y = topYCoordinate_media1[jj] - topYCoordinate_media0[ii]
                    H01_media_top[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)
            H01_media = np.vstack([np.hstack([H01_media_bottom, H01_media_bt]), \
                                   np.hstack([H01_media_tb, H01_media_top])])
        Cell_Hc01[cc + Lc_L] = csr_matrix(H01_media)

    ## 8. Get hopping Hamiltonian between central and terminals
    # Left terminal and Center
    topXCoordinate_mediaL = Cell_topXCoordinate[0]
    topYCoordinate_mediaL = Cell_topYCoordinate[0]
    bottomXCoordinate_mediaL = Xcoordinate_MiddleBottomCell + (-Lc_L - 1) * 2 * np.sqrt(3) * a
    length_top_mediaL = len(topXCoordinate_mediaL)
    # Classifying into two cases:
    if length_top_mediaL == 0:
        Hopping_LC_media = H01
    else:
        Hopping_LC_media = np.zeros([4 * N, 4 * N + length_top_mediaL])
        Hopping_LC_media_bottom = H01
        Hopping_LC_media_bt = np.zeros([4 * N, length_top_mediaL])
        for ii in range(0, 4 * N, 1):
            for jj in range(0, length_top_mediaL, 1):
                r_ij_x = topXCoordinate_mediaL[jj] - bottomXCoordinate_mediaL[ii]
                r_ij_y = topYCoordinate_mediaL[jj] - Ycoordinate_MiddleBottomCell[ii]
                Hopping_LC_media_bt[ii, jj] = t_ij(r_ij_x, r_ij_y, d)
        Hopping_LC_media = np.hstack([Hopping_LC_media_bottom, Hopping_LC_media_bt])

    HLC = Hopping_LC_media

    # Right terminal and Center
    topXCoordinate_mediaR = Cell_topXCoordinate[Lc - 1]
    topYCoordinate_mediaR = Cell_topYCoordinate[Lc - 1]
    bottomXCoordinate_mediaR = Xcoordinate_MiddleBottomCell + (Lc_R + 1) * 2 * np.sqrt(3) * a
    length_top_mediaR = len(topXCoordinate_mediaR)
    # Classifying into two cases:
    if length_top_mediaR == 0:
        Hopping_CR_media = H01
    else:
        Hopping_CR_media = np.zeros([4 * N + length_top_mediaR, 4 * N])
        Hopping_CR_media_bottom = H01
        Hopping_CR_media_tb = np.zeros([length_top_mediaR, 4 * N])
        for ii in range(0, length_top_mediaR, 1):
            for jj in range(0, 4 * N, 1):
                r_ij_x = bottomXCoordinate_mediaR[jj] - topXCoordinate_mediaR[ii]
                r_ij_y = Ycoordinate_MiddleBottomCell[jj] - topYCoordinate_mediaR[ii]
                Hopping_CR_media_tb[ii, jj] = t_ij(r_ij_x, r_ij_y, -d)
        Hopping_CR_media = np.vstack([Hopping_CR_media_bottom, Hopping_CR_media_tb])

    HCR = Hopping_CR_media

    ## Integrate all necessary matrix into a whole matrix
    Matrix_CenterOnsite = Cell_Hc00
    Matrix_CenterHopping = Cell_Hc01

    # Return H00, H01, HLC, HCR, Matrix_CenterOnsite, Matrix_CenterHopping
    return csr_matrix(HLC), csr_matrix(HCR), Matrix_CenterOnsite, Matrix_CenterHopping


'''This program is written to calculate the surface Green's function of
the bottom graphene working as the electrode of a TBG device'''


def SurfaceGF(N, E):
    # Basic parameters
    a = 1.418  # all in units of Angstrom (A)
    epsilon_bottom = 0  # on-site energy, will be fixed in all cases to zero
    eta = 1E-8  # the infinitely-small positive number, unchanged

    # Coordinates for each site in a supercell
    Cell_xcoordinate = a * np.kron(np.array([- np.sqrt(3) / 2, 0, np.sqrt(3) / 2, np.sqrt(3)]), \
                                   np.array([1] * N))
    Y_media1 = a * (Y_coordinate_generator(int(N / 2) + 1) - 3 / 2)
    Y_media1 = Y_media1[1::]
    Y_media1 = np.hstack((-Y_media1[::-1], Y_media1))
    Y_media2 = a * (Y_coordinate_generator(int(N / 2)))
    Y_media2 = np.hstack((-Y_media2[::-1], Y_media2))
    Cell_ycoordinate = np.hstack((Y_media1, Y_media2, Y_media1, Y_media2))

    # Hamiltonian of the supercell (intra)
    H00 = np.zeros([4 * N, 4 * N])
    for ii in range(0, 4 * N - 1, 1):
        for jj in range(ii + 1, 4 * N, 1):
            r_ij_x = Cell_xcoordinate[jj] - Cell_xcoordinate[ii]
            r_ij_y = Cell_ycoordinate[jj] - Cell_ycoordinate[ii]
            H00[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)
    H00 = epsilon_bottom * np.eye(4 * N) + H00 + np.matrix.getH(H00)

    # Hamiltonian of the supercell (inter)
    H01 = np.zeros([4 * N, 4 * N])
    for ii in range(0, 4 * N, 1):
        for jj in range(0, 4 * N, 1):
            r_ij_x = 2 * np.sqrt(3) * a + Cell_xcoordinate[jj] - Cell_xcoordinate[ii]
            r_ij_y = Cell_ycoordinate[jj] - Cell_ycoordinate[ii]
            H01[ii, jj] = t_ij(r_ij_x, r_ij_y, 0)

    # Get the surface Green's function in the Left Terminal
    HL00 = H00
    HL01 = H01
    # 1D prototype
    ai = np.matrix.getH(HL01)
    bi = HL01
    ei = HL00
    eg = HL00
    for ii in range(50):
        mm = np.linalg.inv((1j * eta + E) * np.eye(4 * N) - ei)
        eg = eg + ai @ mm @ bi
        ei = ei + ai @ mm @ bi + bi @ mm @ ai
        ai = ai @ mm @ ai
        bi = bi @ mm @ bi

    grL = np.linalg.inv((1j * eta + E) * np.eye(4 * N) - eg)

    # Rigth Terminal
    HR00 = H00
    HR01 = np.matrix.getH(H01)
    ai = np.matrix.getH(HR01)
    bi = HR01
    ei = HR00
    eg = HR00
    for ii in range(50):
        mm = np.linalg.inv((1j * eta + E) * np.eye(4 * N) - ei)
        eg = eg + ai @ mm @ bi
        ei = ei + ai @ mm @ bi + bi @ mm @ ai
        ai = ai @ mm @ ai
        bi = bi @ mm @ bi

    grR = np.linalg.inv((1j * eta + E) * np.eye(4 * N) - eg)
    return grL, grR



