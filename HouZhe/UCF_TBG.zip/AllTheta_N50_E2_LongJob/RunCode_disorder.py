'''This program is written to fuck python'''
print('hello python \n')
import time
import numpy as np
from scipy.sparse import csr_matrix
from scipy.linalg import block_diag
import matplotlib.pyplot as plt
from Functions_in_TBG import SurfaceGF, Twisted_Coordinates


def RunCode_disorder(E, theta_deg, VdisorderIndex):
    starttime = time.time()
    # Initializing random seed
    np.random.seed(int(VdisorderIndex * 1000) +int(theta_deg * 10000) + int(time.time()))

    Vdisorder = VdisorderIndex * 0.1
    print('theta_deg,', 'Vdisorder: ', theta_deg, ',', Vdisorder)
    # Input parameters
    N = 50
    theta = theta_deg /180 * np.pi
    Ndisorder = 1000
    Tdisorder = np.array([None] * Ndisorder)
    # Basic parameters
    a = 1.418
    a_I = 3.349
    d = a_I * 1
    W = a * (3 * N / 2 - 1)
    R = W / 2
    Lc_L = round(R / (2 * np.sqrt(3) * a)) + 1
    Lc_R = Lc_L  # the number of supercells of the left side in the central region
    Lc = Lc_L + 1 + Lc_R
    eta = 1E-8  # unchanged

    # Surface Green's functions
    grL, grR = SurfaceGF(N, E)
    HLC, HCR, Cell_H00_Center, Cell_H01_Center = Twisted_Coordinates(N, theta, d)

    # Calculating the tranmission coefficients
    SigmaL = (np.matrix.getH(HLC)) @ grL @ HLC
    GammaL = 1j * (SigmaL - np.matrix.getH(SigmaL))
    SigmaR = HCR @ grR @ (np.matrix.getH(HCR))
    GammaR = 1j * (SigmaR - np.matrix.getH(SigmaR))

    # Adding disorder potential to the top layer solely
    for dd in range(Ndisorder):
        #print('dd: ', dd)
        # Calculating the central Green's function using the recursive method
        # The first column
        HC00_media = Cell_H00_Center[0]
        H_disorder_top_media = Vdisorder * np.diagflat(np.random.rand(1, HC00_media.shape[0] - 4 * N) - 1 / 2, 0)
        H_disorder_media = np.vstack([np.hstack([np.zeros([4 * N, 4 * N]), \
                                                 np.zeros([4 * N, HC00_media.shape[0] - 4 * N])]),
                                      np.hstack([np.zeros([HC00_media.shape[0] - 4 * N, 4 * N]), H_disorder_top_media])])
        H_disorder_media = csr_matrix(H_disorder_media)
        Grii = np.linalg.inv((1j * eta + E) * np.eye(HC00_media.shape[0]) - HC00_media - H_disorder_media - SigmaL)
        Gr1i = Grii

        # Central iteration
        for ll in range(1, Lc - 1, 1):
            HC00_media = Cell_H00_Center[ll]
            HC01_media = Cell_H01_Center[ll - 1]
            H_disorder_top_media = Vdisorder * np.diagflat(np.random.rand(1, HC00_media.shape[0] - 4 * N) - 1 / 2, 0)
            H_disorder_media = np.vstack([np.hstack([np.zeros([4 * N, 4 * N]), \
                                                     np.zeros([4 * N, HC00_media.shape[0] - 4 * N])]),
                                          np.hstack([np.zeros([HC00_media.shape[0] - 4 * N, 4 * N]), H_disorder_top_media])])
            H_disorder_media = csr_matrix(H_disorder_media)
            Grii = np.linalg.inv((1j * eta + E) * np.eye(HC00_media.shape[0]) - HC00_media - H_disorder_media \
                                 - np.matrix.getH(HC01_media) @ Grii @ HC01_media)
            Gr1i = Gr1i @ HC01_media @ Grii

        # The last column
        ll = Lc - 1
        HC00_media = Cell_H00_Center[ll]
        HC01_media = Cell_H01_Center[ll - 1]
        H_disorder_top_media = Vdisorder * np.diagflat(np.random.rand(1, HC00_media.shape[0] - 4 * N) - 1 / 2, 0)
        H_disorder_media = np.vstack([np.hstack([np.zeros([4 * N, 4 * N]), \
                                                 np.zeros([4 * N, HC00_media.shape[0] - 4 * N])]),
                                      np.hstack([np.zeros([HC00_media.shape[0] - 4 * N, 4 * N]), H_disorder_top_media])])
        H_disorder_media = csr_matrix(H_disorder_media)
        Grii = np.linalg.inv((1j * eta + E) * np.eye(HC00_media.shape[0]) - HC00_media - H_disorder_media \
                             - np.matrix.getH(HC01_media) @ Grii @ HC01_media - SigmaR)
        Gr1i = Gr1i @ HC01_media @ Grii

        # Calculating the transmission coefficients
        Tdisorder[dd] = np.real(np.trace(GammaL @ Gr1i @ GammaR @ (np.matrix.getH(Gr1i))))
        
    endtime = time.time()
    print(endtime - starttime)

    np.savetxt('Tdisorder' + '_VdisorderIndex' + str(VdisorderIndex) + '_N' + str(N) + '_thetadeg' + str(theta_deg) + '_d' + str(d) + '_E' + str(E) + '.txt', Tdisorder)

