from RunCode_disorder import RunCode_disorder

E = 0.85 
n = 100 
for ii in range(23, 31, 1):
     theta_deg = ii
     for jj in range(1, n+1):
          RunCode_disorder(E, theta_deg, jj)
          print('\n')


